// See the file "COPYING" in the main distribution directory for copyright.

#ifndef scriptanaly_h
#define scriptanaly_h

void notice_analysis();

#endif
