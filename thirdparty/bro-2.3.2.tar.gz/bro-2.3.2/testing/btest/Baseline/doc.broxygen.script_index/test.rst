.. toctree::
   :maxdepth: 1

   broxygen/__load__.bro </scripts/broxygen/__load__.bro>
   broxygen/example.bro </scripts/broxygen/example.bro>
